const path = require('path'), os = require('os'), fs = require('fs');
const express = require('express'), { Server } = require('socket.io');
const PORT = process.env.PORT || 3000;
const app = express();
const server = process.env.SSL_KEY && process.env.SSL_CERT
  ? require('https').createServer({ key: fs.readFileSync(process.env.SSL_KEY), cert: fs.readFileSync(process.env.SSL_CERT) }, app)
  : require('http').createServer(app);
const io = new Server(server);
app.use(express.static(path.join(__dirname, 'public')));

const THEMES = {
  orbita:    { n: 'Órbita',    h: [326, 24, 50, 160, 200, 236, 280], bg: ['#0a0733', '#140d4d', '#0d0a3b'] },
  aurora:    { n: 'Aurora',    h: [150, 170, 190, 210, 130, 95, 260], bg: ['#021a1f', '#06343a', '#04222a'] },
  atardecer: { n: 'Atardecer', h: [350, 10, 25, 40, 55, 330, 300],   bg: ['#2a0a2e', '#4a1239', '#2a0c2a'] },
  nebulosa:  { n: 'Nebulosa',  h: [270, 290, 310, 250, 230, 330, 200], bg: ['#0d0630', '#1d0b52', '#10063a'] },
};
const CLIENT = {
  LANES: 7, LIVES: 3, SHIP_HALF: 0.07, METEOR_R: 0.11, SHIP_LIM: 0.92, SHIP_MAX_SPEED: 3.2,
  COOLDOWN_BASE: 400, COOLDOWN_PER: 80, THEMES,
};
const CFG = {
  ...CLIENT,
  SPEED_MIN: 0.18, SPEED_MAX: 0.85, MAX_METEORS: 60, MAX_PLAYERS: 40,
  INVULN: 1.6, COUNTDOWN: 3, HIT_T: 0.03, REMOVE_T: -0.14,
};
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const laneX = i => ((i + 0.5) / CFG.LANES) * 2 - 1;
const sock = id => io.sockets.sockets.get(id);
const rooms = new Map();
const newRoom = (code, theme) => ({ code, theme, phase: 'waiting', pilot: null, ship: 0, target: 0, lives: CFG.LIVES, time: 0, inv: 0, cd: 0, best: 0, seq: 0, m: [], players: new Set() });
const toWaiting = R => Object.assign(R, { phase: 'waiting', ship: 0, target: 0, lives: CFG.LIVES, time: 0, inv: 0, m: [] });
const start = R => Object.assign(R, { phase: 'countdown', cd: CFG.COUNTDOWN, lives: CFG.LIVES, time: 0, inv: 0, m: [] });
const roster = R => io.to(R.code).emit('roster', [...R.players].map(sock).filter(Boolean).map(s => ({ id: s.id, name: s.data.name, hits: s.data.hits || 0, pilot: s.id === R.pilot })));

function step(R, dt) {
  const d = clamp(R.target - R.ship, -CFG.SHIP_MAX_SPEED * dt, CFG.SHIP_MAX_SPEED * dt);
  R.ship = clamp(R.ship + d, -CFG.SHIP_LIM, CFG.SHIP_LIM);
  if (R.phase === 'countdown') { R.cd -= dt; if (R.cd <= 0) { R.phase = 'playing'; R.cd = 0; } return; }
  if (R.phase === 'playing') { R.time += dt; R.inv = Math.max(0, R.inv - dt); }
  if (R.phase === 'waiting') return;
  for (const m of R.m) {
    m.t -= m.v * dt;
    if (R.phase === 'playing' && !m.done && m.t <= CFG.HIT_T) {
      m.done = true;
      if (R.inv <= 0 && Math.abs(m.x - R.ship) < CFG.SHIP_HALF + CFG.METEOR_R) {
        m.hit = true; R.lives--; R.inv = CFG.INVULN;
        io.to(R.code).emit('hit');
        const o = sock(m.owner); if (o) { o.data.hits = (o.data.hits || 0) + 1; o.emit('scored', { hits: o.data.hits }); roster(R); }
        if (R.lives <= 0) { R.phase = 'over'; R.best = Math.max(R.best, Math.floor(R.time * 10)); }
      }
    }
  }
  R.m = R.m.filter(m => m.t > CFG.REMOVE_T && !m.hit);
}
let last = Date.now();
setInterval(() => { const n = Date.now(), dt = Math.min(0.05, (n - last) / 1000); last = n; for (const R of rooms.values()) step(R, dt); }, 1000 / 60);
setInterval(() => { for (const R of rooms.values()) io.to(R.code).emit('state', {
  p: R.phase, sx: +R.ship.toFixed(3), l: R.lives, s: Math.floor(R.time * 10), b: R.best, cd: Math.ceil(R.cd), inv: R.inv > 0,
  m: R.m.map(m => [m.id, +m.x.toFixed(3), +m.t.toFixed(3), m.v, m.hue, m.seed]), pilot: !!R.pilot, pn: R.pilot && sock(R.pilot) ? sock(R.pilot).data.name : '', n: R.players.size,
}); }, 1000 / 30);

function draw(R, exclude) {
  const all = [...R.players].map(sock).filter(Boolean); if (!all.length) return;
  const pool = all.filter(s => s.id !== exclude), list = pool.length ? pool : all, pick = list[Math.floor(Math.random() * list.length)];
  R.pilot = pick.id; toWaiting(R);
  for (const s of all) { s.data.role = s === pick ? 'pilot' : 'thrower'; s.emit('role', s.data.role); }
  roster(R);
}
function leave(socket) {
  const R = rooms.get(socket.data.room); if (!R) return;
  R.players.delete(socket.id); socket.leave(R.code); socket.data.room = null; socket.data.role = null;
  if (R.pilot === socket.id) { R.pilot = null; toWaiting(R); for (const s of [...R.players].map(sock).filter(Boolean)) { s.data.role = 'lobby'; s.emit('role', 'lobby'); } }
  if (!R.players.size) rooms.delete(R.code); else roster(R);
}

io.on('connection', socket => {
  socket.emit('welcome', CLIENT);
  const rm = () => rooms.get(socket.data.room);
  socket.on('rooms', (cb = () => {}) => cb([...rooms.values()].sort((a, b) => b.players.size - a.players.size).slice(0, 8).map(R => ({ code: R.code, theme: R.theme, n: R.players.size }))));
  socket.on('enter', (a, cb = () => {}) => {
    a = a || {};
    const name = String(a.name || '').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 14) || 'Jugador';
    const code = String(a.room || '').toUpperCase().replace(/[^A-Z0-9-]/g, '').slice(0, 12) || 'GENERAL';
    leave(socket);
    let R = rooms.get(code);
    if (R && R.players.size >= CFG.MAX_PLAYERS) return cb({ ok: false, msg: 'La sala está llena' });
    if (!R) { R = newRoom(code, THEMES[a.theme] ? a.theme : 'orbita'); rooms.set(code, R); }
    Object.assign(socket.data, { name, room: code, hits: 0, role: R.pilot ? 'thrower' : 'lobby' });
    socket.join(code); R.players.add(socket.id);
    cb({ ok: true, theme: R.theme, room: code, name });
    socket.emit('role', socket.data.role); roster(R);
  });
  socket.on('leave', () => leave(socket));
  socket.on('draw', () => { const R = rm(); if (R && (!R.pilot || R.phase === 'over')) draw(R, R.phase === 'over' ? R.pilot : null); });
  socket.on('pass', () => { const R = rm(); if (R && socket.id === R.pilot && R.phase !== 'playing' && R.phase !== 'countdown') draw(R, socket.id); });
  socket.on('steer', x => { const R = rm(); if (R && socket.id === R.pilot && Number.isFinite(x)) R.target = clamp(x, -1, 1) * CFG.SHIP_LIM; });
  socket.on('ready', () => { const R = rm(); if (R && socket.id === R.pilot && R.phase !== 'countdown' && R.phase !== 'playing') start(R); });
  socket.on('throw', (a, cb = () => {}) => {
    const R = rm(); if (!R || socket.data.role !== 'thrower' || R.phase !== 'playing' || !a) return cb({ ok: false, reason: 'inactive' });
    const lane = Math.round(+a.lane), speed = clamp(Math.round(+a.speed), 1, 10), now = Date.now();
    if (!(lane >= 0 && lane < CFG.LANES)) return cb({ ok: false, reason: 'bad' });
    const wait = (socket.data.next || 0) - now;
    if (wait > 0) return cb({ ok: false, reason: 'cooldown', wait });
    if (R.m.length >= CFG.MAX_METEORS) return cb({ ok: false, reason: 'full' });
    socket.data.next = now + CFG.COOLDOWN_BASE + speed * CFG.COOLDOWN_PER;
    const hs = THEMES[R.theme].h;
    R.m.push({ id: ++R.seq, x: laneX(lane), t: 1, v: +(CFG.SPEED_MIN + ((speed - 1) / 9) * (CFG.SPEED_MAX - CFG.SPEED_MIN)).toFixed(3),
      hue: hs[Math.floor(Math.random() * hs.length)], seed: +Math.random().toFixed(2), owner: socket.id });
    cb({ ok: true });
  });
  socket.on('disconnect', () => leave(socket));
});

server.listen(PORT, () => {
  const ip = Object.values(os.networkInterfaces()).flat().find(i => (i.family === 'IPv4' || i.family === 4) && !i.internal);
  console.log(`Jugar en esta compu: http://localhost:${PORT}`);
  if (ip) console.log(`Celulares / otras compus (misma red): http://${ip.address}:${PORT}`);
});

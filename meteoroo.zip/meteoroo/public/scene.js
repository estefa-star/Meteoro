const Scene = (() => {
  const T = Math.PI * 2, K = 6, HUES = [326, 24, 50, 160, 200, 236, 280];
  const rnd = (a, b) => a + Math.random() * (b - a), cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const hsl = (h, s, l, a = 1) => `hsla(${h},${s}%,${l}%,${a})`;
  const FONT = px => `700 ${px}px "Trebuchet MS",system-ui,sans-serif`;
  const star = (c, x, y, R, r) => { c.beginPath(); for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + i * Math.PI / 5, d = i % 2 ? r : R; c[i ? 'lineTo' : 'moveTo'](x + Math.cos(a) * d, y + Math.sin(a) * d); } c.closePath(); };
  const sparkle = (c, x, y, R) => { c.beginPath(); c.moveTo(x, y - R); c.quadraticCurveTo(x, y, x + R, y); c.quadraticCurveTo(x, y, x, y + R); c.quadraticCurveTo(x, y, x - R, y); c.quadraticCurveTo(x, y, x, y - R); c.closePath(); };

  function create(cv, o = {}) {
    let hues = HUES.slice(), bgc = ['#0a0733', '#140d4d', '#0d0a3b'];
    const c = cv.getContext('2d'), cfg = { LANES: 7, METEOR_R: .11, SHIP_HALF: .07, LIVES: 3, ...o.cfg };
    let aim = { lane: -1, charge: 0, press: false, cool: false }, W, H, cx, hy, sy, hw, time = 0, last = performance.now(), ship = 0, tilt = 0, local = null, shake = 0, flash = 0, acc = 0, run = false;
    const v = { p: 'waiting', sx: 0, l: cfg.LIVES, s: 0, b: 0, cd: 0, inv: false, m: [], at: performance.now() }, parts = [], deco = [];
    const lx = i => (i + .5) / cfg.LANES * 2 - 1, shipR = () => cfg.SHIP_HALF * hw * 1.5;
    const newDeco = init => ({ a: rnd(0, T), r: init ? Math.random() : rnd(0, .05), k: Math.floor(rnd(0, 2)), h: hues[Math.floor(rnd(0, 7))], z: rnd(.5, .9), v: rnd(.6, 1) });
    for (let i = 0; i < 14; i++) deco.push(newDeco(true));

    function resize() {
      const b = cv.getBoundingClientRect(), d = Math.min(devicePixelRatio || 1, 2);
      W = Math.max(1, b.width | 0); H = Math.max(1, b.height | 0); cv.width = W * d; cv.height = H * d; c.setTransform(d, 0, 0, d, 0, 0);
      cx = W / 2; hy = H * .3; sy = H * .82; hw = Math.min(W * .46, H * .72);
    }
    function burst(x, y) { for (let i = 0; i < 30; i++) { const a = rnd(0, T), s = rnd(80, 320), l = rnd(.5, 1); parts.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s, l, m: l, h: hues[i % 7], z: rnd(3, 8), sp: i % 3 === 0 }); } }

    function update(dt) {
      time += dt;
      const tg = local !== null ? local : v.sx, prev = ship;
      ship += (tg - ship) * Math.min(1, dt * 16);
      tilt += (cl((ship - prev) / Math.max(dt, 1e-3) * .25, -.5, .5) - tilt) * Math.min(1, dt * 10);
      for (const d of deco) { d.r += (.008 + d.r * .1) * d.v * dt; if (d.r > 1.25) Object.assign(d, newDeco(false)); }
      shake = Math.max(0, shake - dt * 2.2); flash = Math.max(0, flash - dt * 2.5);
      for (const p of parts) { p.x += p.vx * dt; p.y += p.vy * dt; p.l -= dt; }
      for (let i = parts.length - 1; i >= 0; i--) if (parts[i].l <= 0) parts.splice(i, 1);
      if (v.p !== 'over') for (acc += dt; acc > .03; acc -= .03) parts.push({ x: cx + ship * hw + rnd(-5, 5), y: sy + shipR() * .8, vx: -tilt * 120 + rnd(-15, 15), vy: rnd(70, 140), l: .55, m: .55, h: hues[Math.floor(rnd(0, 7))], z: rnd(2.5, 5.5) });
    }

    function drawDeco() {
      for (const d of deco) {
        const s = Math.sin(d.a), x = cx + Math.cos(d.a) * d.r * W * .75, y = hy + s * d.r * (s < 0 ? hy * 1.35 : (H - hy) * 1.05);
        const al = Math.min(1, d.r * 5) * (1 - cl((d.r - .95) / .3, 0, 1)); if (al < .03) continue;
        const z = (2 + d.r * 12) * d.z, col = hsl(d.h, 95, 72);
        c.globalAlpha = al * .45; c.fillStyle = col;
        if (d.k === 0) { c.beginPath(); c.arc(x, y, z * .5, 0, T); c.fill(); }
        else { sparkle(c, x, y, z * 1.1); c.fillStyle = '#fff6d6'; c.fill(); }
      }
      c.globalAlpha = 1;
    }

    function drawRibbons() {
      const n = 26, lw = 2 / cfg.LANES;
      for (let i = 0; i < cfg.LANES; i++) {
        const h = hues[i % 7], L = [], R = [];
        for (let k = 0; k <= n; k++) {
          const s = .03 * Math.pow(2.2 / .03, k / n), lg = Math.log(1 / s);
          const w = lx(i) + Math.sin(time * .9 + i * 1.7 + lg * 2.2) * .06, e = lw * .44 * (1 + .1 * Math.sin(time * 1.3 + i + lg * 3)), y = hy + (sy - hy) * s;
          L.push([cx + (w - e) * hw * s, y]); R.push([cx + (w + e) * hw * s, y]);
        }
        const g = c.createLinearGradient(0, hy, 0, H);
        g.addColorStop(0, hsl(h, 100, 80, .95)); g.addColorStop(.35, hsl(h, 95, 62, .55)); g.addColorStop(1, hsl(h, 90, 55, .28));
        c.fillStyle = g; c.beginPath(); L.forEach((p, k) => c[k ? 'lineTo' : 'moveTo'](p[0], p[1])); for (let k = n; k >= 0; k--) c.lineTo(R[k][0], R[k][1]); c.closePath(); c.fill();
        if (aim.lane === i) { c.save(); c.globalCompositeOperation = 'lighter'; c.fillStyle = `rgba(255,255,255,${(aim.cool ? .06 : .12) + .3 * aim.charge})`; c.fill(); c.restore(); }
      }
    }

    function drawPortal() {
      const R = Math.min(W, H) * .4, g = c.createRadialGradient(cx, hy, 0, cx, hy, R);
      g.addColorStop(0, 'rgba(255,245,215,.7)'); g.addColorStop(.25, 'rgba(255,225,170,.25)'); g.addColorStop(1, 'rgba(255,190,120,0)');
      c.fillStyle = g; c.fillRect(cx - R, hy - R, R * 2, R * 2);
    }

    function drawAim() {
      if (aim.lane < 0) return;
      const q = .22, x = cx + lx(aim.lane) * hw * q, y = hy + (sy - hy) * q, k = aim.charge, r = 12 + 18 * k;
      c.save(); c.globalAlpha = aim.cool ? .35 : 1;
      const g = c.createRadialGradient(x, y, 0, x, y, r * 2); g.addColorStop(0, 'rgba(255,255,255,.9)'); g.addColorStop(.4, hsl(hues[aim.lane % 7], 100, 70, .6)); g.addColorStop(1, 'rgba(255,255,255,0)');
      c.fillStyle = g; c.beginPath(); c.arc(x, y, r * 2, 0, T); c.fill();
      if (aim.press) {
        c.strokeStyle = '#fff3c4'; c.lineWidth = 4; c.lineCap = 'round'; c.beginPath(); c.arc(x, y, r + 6, -Math.PI / 2, -Math.PI / 2 + T * k); c.stroke();
        c.fillStyle = '#2a1450'; c.font = FONT(r); c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(1 + Math.round(k * 9), x, y + 1);
      }
      c.restore();
    }

    function drawMeteor(m) {
      const s = 1 / (1 + K * m.t), x = cx + m.x * hw * s, y = hy + (sy - hy) * s, r = cfg.METEOR_R * hw * s; if (r < 1.2) return;
      c.save(); c.globalAlpha = cl((1 - m.t) * 6, 0, 1) * (m.t < -.06 ? cl(1 - (-.06 - m.t) / .08, 0, 1) : 1);
      let dx = cx - x, dy = hy - y; const dl = Math.hypot(dx, dy) || 1; dx /= dl; dy /= dl;
      const tl = r * (1.6 + m.v * 3.2), px = -dy, py = dx, tg = c.createLinearGradient(x, y, x + dx * tl, y + dy * tl);
      tg.addColorStop(0, hsl(m.hue, 95, 70, .75)); tg.addColorStop(1, hsl(m.hue, 95, 70, 0)); c.fillStyle = tg;
      c.beginPath(); c.moveTo(x + px * r * .9, y + py * r * .9);
      c.quadraticCurveTo(x + dx * tl * .6 + px * r * .5, y + dy * tl * .6 + py * r * .5, x + dx * tl, y + dy * tl);
      c.quadraticCurveTo(x + dx * tl * .6 - px * r * .5, y + dy * tl * .6 - py * r * .5, x - px * r * .9, y - py * r * .9); c.fill();
      const N = 9, pts = []; for (let k = 0; k < N; k++) { const a = k / N * T, q = r * (1 + .14 * Math.sin(k * 2.3 + m.seed * 6.28 + time * 2.4)); pts.push([x + Math.cos(a) * q, y + Math.sin(a) * q]); }
      const mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2], p0 = mid(pts[N - 1], pts[0]);
      c.beginPath(); c.moveTo(p0[0], p0[1]); for (let k = 0; k < N; k++) { const q = mid(pts[k], pts[(k + 1) % N]); c.quadraticCurveTo(pts[k][0], pts[k][1], q[0], q[1]); } c.closePath();
      const bg = c.createRadialGradient(x - r * .35, y - r * .35, r * .1, x, y, r * 1.1);
      bg.addColorStop(0, hsl(m.hue, 100, 90)); bg.addColorStop(.55, hsl(m.hue, 95, 66)); bg.addColorStop(1, hsl((m.hue + 25) % 360, 90, 46));
      c.fillStyle = bg; c.fill(); c.fillStyle = 'rgba(255,255,255,.55)'; c.beginPath(); c.ellipse(x - r * .35, y - r * .38, r * .22, r * .12, -.6, 0, T); c.fill(); c.restore();
    }

    function drawShip() {
      const R = shipR(); c.save(); if (v.inv) c.globalAlpha = Math.sin(time * 32) > 0 ? 1 : .35;
      c.translate(cx + ship * hw, sy + Math.sin(time * 3) * 3); c.rotate(tilt);
      const g = c.createRadialGradient(0, 0, 0, 0, 0, R * 2.4); g.addColorStop(0, 'rgba(255,230,140,.55)'); g.addColorStop(1, 'rgba(255,230,140,0)');
      c.fillStyle = g; c.beginPath(); c.arc(0, 0, R * 2.4, 0, T); c.fill();
      star(c, 0, 0, R, R * .5); const b = c.createRadialGradient(-R * .2, -R * .3, R * .1, 0, 0, R); b.addColorStop(0, '#fff8cf'); b.addColorStop(1, '#ffc93c');
      c.fillStyle = b; c.strokeStyle = '#ffd95e'; c.lineWidth = R * .28; c.lineJoin = 'round'; c.fill(); c.stroke();
      c.fillStyle = c.strokeStyle = '#6a3b12'; for (const d of [-1, 1]) { c.beginPath(); c.arc(d * R * .2, 0, R * .07, 0, T); c.fill(); }
      c.lineWidth = R * .07; c.lineCap = 'round'; c.beginPath(); c.arc(0, R * .05, R * .2, .15 * Math.PI, .85 * Math.PI); c.stroke(); c.restore();
    }

    function drawHud() {
      for (let i = 0; i < cfg.LIVES; i++) { star(c, 26 + i * 30, 28, 11, 5.2); if (i < v.l) { c.fillStyle = '#ffd34d'; c.fill(); } else { c.strokeStyle = 'rgba(255,243,196,.4)'; c.lineWidth = 2; c.stroke(); } }
      c.textAlign = 'right'; c.fillStyle = '#fff3c4'; c.font = FONT(22); c.fillText((v.s / 10).toFixed(1) + ' s', W - 16, 34);
      if (v.b) { c.font = FONT(14); c.globalAlpha = .7; c.fillText('mejor ' + (v.b / 10).toFixed(1) + ' s', W - 16, 54); c.globalAlpha = 1; }
      if (v.p === 'countdown') { c.textAlign = 'center'; c.font = FONT(Math.min(W, H) * .3); c.shadowColor = '#ff9acb'; c.shadowBlur = 30; c.fillText(v.cd, cx, H * .55); c.shadowBlur = 0; }
    }

    function draw() {
      c.save(); if (shake) c.translate(rnd(-1, 1) * shake * 10, rnd(-1, 1) * shake * 10);
      const bg = c.createLinearGradient(0, 0, 0, H); bg.addColorStop(0, bgc[0]); bg.addColorStop(.35, bgc[1]); bg.addColorStop(1, bgc[2]);
      c.fillStyle = bg; c.fillRect(-20, -20, W + 40, H + 40);
      drawDeco(); drawRibbons(); drawPortal(); drawAim();
      const dt = Math.min(.12, (performance.now() - v.at) / 1000);
      const ms = v.m.map(m => ({ ...m, t: m.t - m.v * dt })).sort((a, b) => b.t - a.t);
      ms.forEach(m => m.t > 0 && drawMeteor(m)); drawShip(); if (v.pn) { c.font = FONT(15); c.textAlign = 'center'; c.fillStyle = 'rgba(255,243,196,.9)'; c.fillText(v.pn, cx + ship * hw, sy + shipR() * 1.95); } ms.forEach(m => m.t <= 0 && m.t > -.16 && drawMeteor(m));
      for (const p of parts) { c.globalAlpha = p.l / p.m; c.fillStyle = hsl(p.h, 95, 70); if (p.sp) { sparkle(c, p.x, p.y, p.z * 1.4); c.fill(); } else { c.beginPath(); c.arc(p.x, p.y, p.z * (p.l / p.m), 0, T); c.fill(); } }
      c.globalAlpha = 1; if (flash) { c.fillStyle = `rgba(255,80,170,${flash * .25})`; c.fillRect(-20, -20, W + 40, H + 40); }
      c.restore(); drawHud();
    }

    function loop(n) { if (!run) return; const dt = Math.min(.05, (n - last) / 1000); last = n; update(dt); draw(); requestAnimationFrame(loop); }
    new ResizeObserver(resize).observe(cv); resize();
    return {
      start() { run = true; last = performance.now(); requestAnimationFrame(loop); },
      setState(s) { Object.assign(v, s, { m: s.m.map(a => ({ id: a[0], x: a[1], t: a[2], v: a[3], hue: a[4], seed: a[5] })), at: performance.now() }); },
      hit() { shake = 1; flash = 1; burst(cx + ship * hw, sy); },
      setLocalShip(x) { local = x; },
      setTheme(t) { hues = t.h.slice(); bgc = t.bg.slice(); deco.forEach(d => d.h = hues[Math.floor(rnd(0, 7))]); },
      setAim(lane, charge, press, cool) { aim = { lane, charge, press, cool }; },
      laneAt(x, y) { const q = Math.max(.12, (y - hy) / (sy - hy)), w = (x - cx) / (hw * q); return cl(Math.floor((w + 1) / 2 * cfg.LANES), 0, cfg.LANES - 1); },
    };
  }
  return { create };
})();
